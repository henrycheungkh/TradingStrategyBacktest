# -*- coding: utf-8 -*-
"""
Created on Sat Jan 21 15:55:44 2023

@author: Henry Cheung
"""


# import smtplib
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# mail_content = '''Hello,
# This is a simple mail. There is only text, no attachments are there The mail is sent using Python SMTP library.
# Thank You
# '''

# #The mail addresses and password
# # sender_address = 'lostintokyo99@gmail.com'
# sender_address = 'lostintokyo9919@yahoo.com'

# sender_pass = 'Trade1Analysis2For3Real4'
# receiver_address = 'henry.cheungkh@gmail.com'
# #Setup the MIME
# message = MIMEMultipart()
# message['From'] = sender_address
# message['To'] = receiver_address
# message['Subject'] = 'A test mail sent by Python. It has an attachment.'   #The subject line
# #The body and the attachments for the mail
# message.attach(MIMEText(mail_content, 'plain'))
# #Create SMTP session for sending the mail
# # session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
# # session = smtplib.SMTP('smtp.sendgrid.net', 587) #use sendgrid with port
# session = smtplib.SMTP('smtp.mail.yahoo.com', 587) #use yahoo with port


# session.starttls() #enable security
# session.login(sender_address, sender_pass) #login with mail_id and password
# # session.login('apikey', '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') #login with mail_id and password
# text = message.as_string()
# session.sendmail(sender_address, receiver_address, text)
# session.quit()
# print('Mail Sent')


# -----------------------



from datetime import date, datetime, timedelta
import ssl
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email_yahoo(subject,message_body, 
                      my_email, my_email_pass, 
                      target_emails, private_or_group,
                      attachment, 
                      attachment_file, attachment_assign_name):
    notification_email_date=datetime.now().strftime(' %d.%m.%Y %H-%M-%S')
    context = ssl.create_default_context()  
       
    if private_or_group == 'private':
        for target_email in target_emails:        
            with smtplib.SMTP_SSL("smtp.mail.yahoo.com", 465, context = context) as server:
                server.login(my_email, my_email_pass)
                message = MIMEMultipart("alternative")
                message["Subject"] = subject
                message["From"] = my_email
                message["To"] = target_email
                part = MIMEText(message_body, "plain")
                message.attach(part)
                
                if attachment:
                    part = MIMEBase('application', "octet-stream")
                    part.set_payload(open(attachment_file, "rb").read())
                    encoders.encode_base64(part)
                    part.add_header('Content-Disposition', 'attachment; filename=%s'%(attachment_assign_name))
                    message.attach(part)

                server.sendmail (my_email,target_email, message.as_string())
                server.quit()
                print('private email sent to', message["To"])
                time.sleep(2)
                
    elif private_or_group == 'group':
        with smtplib.SMTP_SSL("smtp.mail.yahoo.com", 465, context = context) as server:        
            server.login(my_email, my_email_pass)
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = my_email
            message["To"] = ', '.join(target_emails)
            part = MIMEText(message_body, "plain")
            message.attach(part)
            
            if attachment:
                part = MIMEBase('application', "octet-stream")
                part.set_payload(open(attachment_file, "rb").read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment; filename=%s'%(attachment_assign_name))
                message.attach(part)
                    
            server.sendmail (my_email, target_emails, message.as_string())
            server.quit()
            print('group email sent to', message["To"])
            time.sleep(2)

subject = 'Emial Subject' # subject of the email

message_body = """\
Dear Mr. Ms. 
Email body line 1.
Email body line 2.
Best regards
Mr. X
."""

private_or_group = 'group'  # 'group 'or 'private'

attachment = True
attachment_file = "C:/Users/X/Desktop/X.jpg"
attachment_assign_name = 'X.jpg'

attachment = False



my_email = 'lostintokyo9919@yahoo.com'
my_email_pass = 'Trade1Analysis2For3Real4'

target_emails = ['henry.cheungkh@gmail.com']

send_email_yahoo(subject,message_body,
                  my_email, my_email_pass,
                  target_emails, private_or_group, 
                  attachment,
                  attachment_file, attachment_assign_name)
