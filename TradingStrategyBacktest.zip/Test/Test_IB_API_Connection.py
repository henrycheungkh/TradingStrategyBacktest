# -*- coding: utf-8 -*-
"""
Created on Sat Apr 24 04:01:48 2021

@author: Henry Cheung
"""


from ibapi.client import EClient
from ibapi.wrapper import EWrapper  

class IBapi(EWrapper, EClient):
     def __init__(self):
         EClient.__init__(self, self) 

app = IBapi()
app.connect('127.0.0.1', 7496, 123)
app.run()


#Uncomment this section if unable to connect
#and to prevent errors on a reconnect
import time
time.sleep(2)
app.disconnect()
