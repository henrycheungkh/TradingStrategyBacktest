# -*- coding: utf-8 -*-
"""
Created on Sat Jan 21 15:55:44 2023

@author: Henry Cheung
"""


# import smtplib
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# mail_content = '''Hello,
# This is a simple mail. There is only text, no attachments are there The mail is sent using Python SMTP library.
# Thank You
# '''

# #The mail addresses and password
# sender_address = 'lostintokyo99@gmail.com'
# sender_pass = 'Trade1Analysis2For3Real4'
# receiver_address = 'henry.cheungkh@gmail.com'
# #Setup the MIME
# message = MIMEMultipart()
# message['From'] = sender_address
# message['To'] = receiver_address
# message['Subject'] = 'A test mail sent by Python. It has an attachment.'   #The subject line
# #The body and the attachments for the mail
# message.attach(MIMEText(mail_content, 'plain'))
# #Create SMTP session for sending the mail
# # session = smtplib.SMTP('smtp.gmail.com', 587) #use gmail with port
# session = smtplib.SMTP('smtp.sendgrid.net', 587) #use gmail with port
# session.starttls() #enable security
# # session.login(sender_address, sender_pass) #login with mail_id and password
# session.login('apikey', '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') #login with mail_id and password
# text = message.as_string()
# session.sendmail(sender_address, receiver_address, text)
# session.quit()
# print('Mail Sent')

# import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

message = Mail(
    from_email='lostintokyo99@gmail.com',
    to_emails='henry.cheungkh@gmail.comm',
    subject='Sending with Twilio SendGrid is Fun2',
    html_content='<strong>and easy to do anywhere, even with Python</strong>')
try:
    # sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
    # sg = SendGridAPIClient('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')
    sg = SendGridAPIClient(r'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')
    response = sg.send(message)
    print(response.status_code)
    print(response.body)
    print(response.headers)
except Exception as e:
    print(e.message)

