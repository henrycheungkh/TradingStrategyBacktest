# -*- coding: utf-8 -*-
"""
Created on Sat Apr 24 04:08:55 2021

@author: Henry Cheung
"""


from ibapi.client import EClient
from ibapi.wrapper import EWrapper
# from ibapi.contract import Contract
from ibapi.contract import *
from ibapi.common import *

import threading
import time

class IBapi(EWrapper, EClient):
	def __init__(self):
		EClient.__init__(self, self)
	def historicalData(self, reqId, bar):
		print("HistoricalData. ReqId:", reqId, "BarData.", bar)
# 		print(f'Time: {bar.date} Close: {bar.close}')

	def historicalDataEnd(self, reqId: int, start: str, end: str):
		print("HistoricalDataEnd. ReqId:", reqId, "from", start, "to", end)

	def error(self, reqId: TickerId, errorCode: int, errorString: str):
		print("Error. Id:", reqId, "Code:", errorCode, "Msg:", errorString)

		
def run_loop():
	app.run()

app = IBapi()
app.connect('127.0.0.1', 7496, 123)

#Start the socket in a thread
api_thread = threading.Thread(target=run_loop, daemon=True)
api_thread.start()

time.sleep(1) #Sleep interval to allow time for connection to server

#Create contract object
# contract = Contract()
# contract.symbol = 'EUR'
# contract.secType = 'CASH'
# contract.exchange = 'IDEALPRO'
# contract.currency = 'USD'

contract = Contract()
contract.symbol = "YM"
contract.secType = "FUT"
contract.exchange = "ECBOT"
contract.currency = "USD"
contract.lastTradeDateOrContractMonth = "202106"

#Request historical candles
# app.reqHistoricalData(1, contract, '', '2 D', '1 hour', 'BID', 0, 2, False, [])
app.reqHistoricalData(1, contract, '', "3 D", "10 secs", "TRADES", 0, 1, False, [])

time.sleep(5) #sleep to allow enough time for data to be returned
app.disconnect()