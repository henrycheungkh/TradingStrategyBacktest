# -*- coding: utf-8 -*-
"""
Created on Sun Jul  7 00:15:59 2024

@author: Henry Cheung
"""



import pandas as pd
import numpy as np
import datetime
pd.set_option('display.max_columns', None)
pd.set_option('display.width',300)

def getKeyLevel(KeyLevelFilepath, KeyLevelName):
    df_KeyLevels = pd.read_csv(KeyLevelFilepath)
    
    df_KeyLevels['Key Level Movement'] = df_KeyLevels[KeyLevelName].diff().shift(-1)
    df_KeyLevels = df_KeyLevels[df_KeyLevels[KeyLevelName + 'Layer'] != 0].reset_index()
    
    df_KeyLevels = df_KeyLevels.sort_values(by=['Date', KeyLevelName], ascending=True, inplace=False).reset_index()
    df_KeyLevels['KeyLevelBelow'] = df_KeyLevels[KeyLevelName].shift(1)
    df_KeyLevels['KeyLevelAbove'] = df_KeyLevels[KeyLevelName].shift(-1)
    df_KeyLevels['KeyLevelBelowDate'] = df_KeyLevels['Date'].shift(1)
    df_KeyLevels['KeyLevelAboveDate'] = df_KeyLevels['Date'].shift(-1)
    df_KeyLevels.loc[df_KeyLevels['Date'] != df_KeyLevels['KeyLevelBelowDate'], 'KeyLevelBelow'] = np.nan
    df_KeyLevels.loc[df_KeyLevels['Date'] != df_KeyLevels['KeyLevelAboveDate'], 'KeyLevelAbove'] = np.nan
    
    return df_KeyLevels

def getPriceInSingleSeries(df):

    df['price step 1'] = df['close']
    df['price step 2'] = df['close']
    df.loc[df['close'] > df['open'], 'price step 1'] = df['low']
    df.loc[df['close'] > df['open'], 'price step 2'] = df['high']
    df.loc[df['close'] <= df['open'], 'price step 1'] = df['high']
    df.loc[df['close'] <= df['open'], 'price step 2'] = df['low']
    
    ColumnsToKeep = ['expiry', 'tDateTime', 'TimeInStandardUnit', 'date id', 'MarketTimeSectionID', 'vol', 'Date']
    
    df_1 = df[ColumnsToKeep + ['price step 1']]
    df_1['vol'] = 0
    df_1['price'] = df_1['price step 1']
    df_1['price step key'] = 1
    
    df_2 = df[ColumnsToKeep + ['price step 2']]
    df_2['vol'] = 0
    df_2['price'] = df_2['price step 2']
    df_2['price step key'] = 2
    
    df_3 = df[ColumnsToKeep + ['close']]
    df_3['price'] = df_3['close']
    df_3['price step key'] = 3
    
    df_SingleSeries = pd.concat([df_1, df_2, df_3])
    
    df_SingleSeries.sort_values(by=['tDateTime', 'price step key'], ascending=False, inplace=True)
    
    df_SingleSeries = df_SingleSeries[ColumnsToKeep + ['price', 'price step key']].copy().reset_index()
    
    return df_SingleSeries

def AssignKeyLevel(df_SingleSeries, df_KeyLevels, KeyLevelName):

    df_SingleSeries_WithKL = df_SingleSeries.merge(df_KeyLevels[['Date',KeyLevelName, 'Key Level Movement']], how='left', on=['Date'])
    
    df_SingleSeries_KLDown = df_SingleSeries_WithKL[df_SingleSeries_WithKL[KeyLevelName] < df_SingleSeries_WithKL['price']]
    df_SingleSeries_KLDown = pd.pivot_table(df_SingleSeries_KLDown, values=KeyLevelName, index=['tDateTime', 'price step key'], aggfunc="max").reset_index().rename(columns={KeyLevelName:'KeyLevelDown'}, inplace=False).sort_values(by=['tDateTime', 'price step key'], ascending=False)
    
    df_SingleSeries_KLUp = df_SingleSeries_WithKL[df_SingleSeries_WithKL[KeyLevelName] > df_SingleSeries_WithKL['price']]
    df_SingleSeries_KLUp = pd.pivot_table(df_SingleSeries_KLUp, values=KeyLevelName, index=['tDateTime', 'price step key'], aggfunc="min").reset_index().rename(columns={KeyLevelName:'KeyLevelUp'}, inplace=False).sort_values(by=['tDateTime', 'price step key'], ascending=False)
    
    df_SingleSeries = df_SingleSeries.merge(df_SingleSeries_KLDown, how='left', on=['tDateTime', 'price step key'])
    df_SingleSeries = df_SingleSeries.merge(df_SingleSeries_KLUp, how='left', on=['tDateTime', 'price step key'])
    df_SingleSeries = df_SingleSeries.merge(df_KeyLevels[['Date',KeyLevelName, 'Key Level Movement', 'KeyLevelBelow']], how='left', left_on=['Date', 'KeyLevelDown'], right_on=['Date', KeyLevelName]).rename(columns={'Key Level Movement':'KeyLevelDown Movement'}, inplace=False).drop([KeyLevelName], axis=1, inplace=False)
    df_SingleSeries = df_SingleSeries.merge(df_KeyLevels[['Date',KeyLevelName, 'Key Level Movement', 'KeyLevelAbove']], how='left', left_on=['Date', 'KeyLevelUp'], right_on=['Date', KeyLevelName]).rename(columns={'Key Level Movement':'KeyLevelUp Movement'}, inplace=False).drop([KeyLevelName], axis=1, inplace=False)
    
    return df_SingleSeries

